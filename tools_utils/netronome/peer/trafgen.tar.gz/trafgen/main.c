/*
 *   BSD LICENSE
 *
 *   Copyright (C) 2015 Netronome Systems, Inc.
 *   Copyright (C) 2010-2014 Intel Corporation.
 *   All rights reserved.
 *
 *   Redistribution and use in source and binary forms, with or without
 *   modification, are permitted provided that the following conditions
 *   are met:
 *
 *     * Redistributions of source code must retain the above copyright
 *       notice, this list of conditions and the following disclaimer.
 *     * Redistributions in binary form must reproduce the above copyright
 *       notice, this list of conditions and the following disclaimer in
 *       the documentation and/or other materials provided with the
 *       distribution.
 *     * Neither the name of Intel Corporation nor the names of its
 *       contributors may be used to endorse or promote products derived
 *       from this software without specific prior written permission.
 *
 *   THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *   "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *   LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *   A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *   OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *   SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *   LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *   DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *   THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *   (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *   OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *   This DPDK sample application is derived from the L2FWD sample bundled
 *   with DPDK 1.8.0.
 *
 *   Key features:
 *   - Choice between forwarding the packets unmodified to other ports,
 *     logging packets for debugging or dropping the packets.
 *   - Summary statistics can be recorded for benchmarking.
 *   - A packet generation facility has been added for benchmarking.
 *
 *   Modes of operation:
 *   - Drop mode: default mode that receives a frame and immediately
 *     frees the mbuf. This mode does not verify checksums.
 *   - Forward mode: Assign one lcore per port. Even and odd-numbered ports
 *     forward to each other using burst mode.
 *   - Echo mode: Assign one lcore per port. Source and destination MAC is
 *     swapped and the packet is sent back to the same port.
 *   - Benchmark mode: Assign two lcores per port. The first lcore attempts to
 *     transmit at a specified rate. The second lcore receives the mbuf,
 *     estimates latency and frees the mbuf.
 *   - Asymmetric mode: Assign one lcore per port. All traffic received forwards
 *     to the last port.
 *   - Log mode: Log the full packet to a human-readable file. This is not
 *     intended to be performant.
 *
 *   Packet generation:
 *   - All packets generated will share the same source IP, source MAC and size
 *     profile (fixed or IMIX).
 *   - The destination IP and MAC are selected sequentially in the following
 *     pattern:
 *     a) The stream number is set to 0
 *     b) The stream base is calculated by multiplying the stream number
 *        with the MAC and IP stride.
 *     c) The burst number is set to 0
 *     d) The flow number is set to 0
 *     e) A packet is generated with the destination IP and MAC set to
 *        "stream base" + "flow number"
 *     f) The flow number is increased, if it is less than the number of flows
 *        per stream, loop back to (e) else continue to (g)
 *     g) The burst number is increased, if it is less than the number of bursts
 *        per stream, loop back to (d) else continue to (h)
 *     h) The stream base is incremented, if it is less than the number of
 *        streams, loop back to (b) else continue to (i)
 *     i) loop back to (a)
 *   - This results in a set of streams that are separated by the MAC and IP
 *     stride and repeat in bursts. The destination IP and MAC increase in
 *     lock-step.
 *   - Packet size can be constant, or selected from a 7:4:1 IMIX profile with
 *     packet sizes 1514, 570 and 64, respectively.
 *
 *   To print a summary of command-line parameters, run the application
 *   without parameters.
 *
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include <inttypes.h>
#include <sys/types.h>
#include <sys/queue.h>
#include <arpa/inet.h>
#include <netinet/in.h>
#include <setjmp.h>
#include <stdarg.h>
#include <ctype.h>
#include <errno.h>
#include <getopt.h>
#include <time.h>
#include <signal.h>
#include <math.h>

#include <rte_common.h>
#include <rte_log.h>
#include <rte_memory.h>
#include <rte_memcpy.h>
#include <rte_memzone.h>
#include <rte_tailq.h>
#include <rte_eal.h>
#include <rte_per_lcore.h>
#include <rte_launch.h>
#include <rte_atomic.h>
#include <rte_cycles.h>
#include <rte_prefetch.h>
#include <rte_lcore.h>
#include <rte_per_lcore.h>
#include <rte_branch_prediction.h>
#include <rte_interrupts.h>
#include <rte_pci.h>
#include <rte_random.h>
#include <rte_debug.h>
#include <rte_ether.h>
#include <rte_ethdev.h>
#include <rte_ring.h>
#include <rte_mempool.h>
#include <rte_mbuf.h>
#include <rte_timer.h>
#include <rte_byteorder.h>
#include <rte_ip.h>
#include <rte_tcp.h>
#include <rte_udp.h>
#include <rte_string_fns.h>
#include <rte_random.h>

#define VERSION "0.1"

#define RTE_LOGTYPE_TRAFGEN RTE_LOGTYPE_USER1

/* Change this to 0 to build a version that does not generate a TX checksum
   on the fly */
#define CALCULATE_CHECKSUM 1
/* Change this to 1 to build a version that does not pad the payload on the
   fly */
#define SKIP_PAYLOAD 0
/* Change this to 1 to hard-code the number of flows, number of streams and
   number of bursts to 64 */
#define FAST_GEN 0

/* Set to 1 to disable offloads */
#define DISABLE_OFFLOADS 0

/* NBUF_SIZE must be increased when using jumbo frames */
#define MBUF_SIZE (2048 + sizeof(struct rte_mbuf) + RTE_PKTMBUF_HEADROOM)
/* NB_MBUF should be increased if the number of ring descriptors are
 * increased or the number of ports go up. */
#define NB_MBUF   16384

#define MAX_PKT_BURST 32
#define BURST_TX_DRAIN_US 100 /* TX drain every ~100us */

#define MTU 1550
#define MBUF_DATA_ROOM  9000
/*
 * Configurable number of RX/TX ring descriptors
 */
/* l2fwd original default settings for RX: 128, TX: 512 */
#define RTE_TEST_RX_DESC_DEFAULT 1024
#define RTE_TEST_TX_DESC_DEFAULT 1024
static uint16_t nb_rxd = RTE_TEST_RX_DESC_DEFAULT;
static uint16_t nb_txd = RTE_TEST_TX_DESC_DEFAULT;
static uint8_t nb_ports_available;

/* ethernet addresses of ports */
static struct ether_addr ports_eth_addr[RTE_MAX_ETHPORTS];

/* mask of enabled ports */
static uint32_t enabled_port_mask = 0;

/* list of enabled ports */
static uint32_t dst_ports[RTE_MAX_ETHPORTS];

static FILE* log_files[RTE_MAX_ETHPORTS];

static unsigned int rx_queue_per_lcore = 1;
static unsigned int tx_queue_per_lcore = 1;

struct mbuf_table {
    unsigned len;
    struct rte_mbuf *m_table[MAX_PKT_BURST];
};

#define MAX_RX_QUEUE_PER_LCORE 16
/* Only support one TX queue per lcore at this stage */
#define MAX_TX_QUEUE_PER_LCORE 1
struct lcore_queue_conf {
    unsigned n_tx_port;
    unsigned tx_port_list[MAX_TX_QUEUE_PER_LCORE];
    unsigned n_rx_port;
    unsigned rx_port_list[MAX_RX_QUEUE_PER_LCORE];
    struct mbuf_table tx_mbufs[RTE_MAX_ETHPORTS];

} __rte_cache_aligned;
struct lcore_queue_conf lcore_queue_conf[RTE_MAX_LCORE];

static struct rte_eth_conf port_conf = {
    .rxmode = {
        .split_hdr_size = 0,
        .header_split   = 0, /**< Header Split disabled */
        .hw_ip_checksum = 0, /**< IP checksum offload disabled */
        .hw_vlan_filter = 0, /**< VLAN filtering disabled */
        .jumbo_frame    = 0, /**< Jumbo Frame Support disabled */
        .hw_strip_crc   = 0, /**< CRC stripped by hardware */
    },
    .txmode = {
        .mq_mode = ETH_MQ_TX_NONE,
    },
};

#if DISABLE_OFFLOADS
struct rte_eth_txconf tx_conf = {
    .txq_flags = ETH_TXQ_FLAGS_NOMULTSEGS | ETH_TXQ_FLAGS_NOOFFLOADS,
};
#endif

struct rte_mempool * pktmbuf_pool = NULL;

/* Per-port statistics struct */
struct port_statistics {
    uint64_t rx_bytes;
    uint64_t prev_rx_bytes;
    uint64_t rx_packets;
    uint64_t prev_rx_packets;
    uint64_t tx_bytes;
    uint64_t prev_tx_bytes;
    uint64_t tx_packets;
    uint64_t prev_tx_packets;
    uint64_t tx_dropped;
    uint64_t rx_dropped;
    uint64_t tx_bursts;
    uint64_t tx_short;
    uint64_t tx_alloc_errors;
    uint64_t tx_gen_overrun;
    double rx_mean_latency;
    double rx_m2_latency;
} __rte_cache_aligned;
struct port_statistics port_statistics[RTE_MAX_ETHPORTS];

/* Timer resolution for the statistics printout */
static uint64_t tsc_100hz = 20000000ULL;
static uint64_t timer_hz;

//#define TIMER_RESOLUTION_CYCLES 20000000ULL /* around 10ms at 2 Ghz */
#define MAX_TIMER_PERIOD 86400 /* 1 day max */
#define MAX_RUNTIME 3600 /* 1 hour max (at 1 sec/sample) */
/* default period is 1 second */
static int64_t timer_period = 1;
static int64_t runtime_count = 1;
static int64_t runtime_delta = 0;

static struct rte_timer print_stats_timer;

/* Per-port statistics summary */
struct port_summary {
    uint64_t rx_bytes;
    uint64_t rx_packets;
    uint64_t tx_bytes;
    uint64_t tx_packets;
    double rx_mean_latency;
    double rx_var_latency;
} __rte_cache_aligned;

struct port_summary port_history[RTE_MAX_ETHPORTS][MAX_RUNTIME];
time_t epoch_history[MAX_RUNTIME];

static int histptr = 0;

enum mode { MODE_DROP, MODE_ECHO, MODE_FWD, MODE_LOG, MODE_ASYMMETRIC,
            MODE_BENCH };

static enum mode mode = MODE_DROP;
static unsigned long int port_gui_offset = 0;
static unsigned asymmetric_port = 0;

#define MAX_FNAME_LEN 255
static char summary_fname[MAX_FNAME_LEN+1];

/*
 * Frame creation defaults
 */
#define IP_DEFTTL  64
#define IP_VERSION 0x40
#define IP_HDRLEN  0x05 /* default IP header length == five 32-bits words. */
#define IP_VHL_DEF (IP_VERSION | IP_HDRLEN)
static uint32_t max_seg_len = 20000; /* By default larger than any packet */
static const char *default_payload =
    "\x42\x01\x02\x03 DPDK Payload";
/* Match 4 bytes in the magic */
#define MAGIC_MATCH 4

static uint64_t eth_dst_base = 0x5452deadbeef;
static uint64_t eth_src_base = 0x000d30596955;
static uint64_t eth_stride = 0x010000000000;

static uint32_t ip_src_base = IPv4(192, 168, 50, 10);
static uint32_t ip_dst_base = IPv4(192, 168, 60, 10);
static uint32_t ip_stride = IPv4(0, 0, 0, 1);

/* MAX_TX_BURST_SIZE attempts to pre-allocate packets when waiting for the
 * TX timeout to occur. Making it much bigger causes a lot of extra
 * memmove instructions. */
#define MAX_TX_BURST_SIZE 128
static uint64_t tx_pps = 0;
static unsigned tx_burst_size = 32;
#define MIN_TX_BURST_SIZE 1
static uint32_t flows_per_stream = 65536;
static uint32_t number_of_streams = 1;
static uint32_t burst_per_stream = 1;

static int tx_enable = 0;

static int pkt_size = 68;

/* Print out statistics on packets dropped */
static void print_stats_cb(__attribute__((unused)) struct rte_timer *tim,
                           __attribute__((unused)) void *arg)
{
    uint64_t rx_bytes_delta, rx_packets_delta, total_rx_bytes_delta,
         total_rx_packets_delta, total_tx_packets_delta, total_tx_bytes_delta,
         tx_packets_delta, tx_bytes_delta;
    unsigned portid;
    uint64_t cur_stat;

    const char clr[] = { 27, '[', '2', 'J', '\0' };
    const char topLeft[] = { 27, '[', '1', ';', '1', 'H','\0' };

    static uint64_t total_tx_packets = 0;
    static uint64_t total_tx_bytes = 0;
    static uint64_t total_rx_packets = 0;
    static uint64_t total_rx_bytes = 0;

    static uint64_t total_tx_packets_dropped = 0;
    static uint64_t total_rx_packets_dropped = 0;

    total_rx_packets_delta = 0;
    total_rx_bytes_delta = 0;
    total_tx_packets_delta = 0;
    total_tx_bytes_delta = 0;

    if (histptr == 1) {
        tx_enable = 1;
    }

    /* Clear screen and move to top left */
    printf("%s%s", clr, topLeft);
    printf("\n+======================================================+"
           "\n| Timer period: %38"PRIu64" |",
           timer_period);

    //printf("\n+================= Port statistics ====================+");

    for (portid = 0; portid < RTE_MAX_ETHPORTS; portid++) {
        /* skip disabled ports */
        if ((enabled_port_mask & (1 << portid)) == 0)
            continue;

        cur_stat = port_statistics[portid].rx_bytes;
        rx_bytes_delta = cur_stat - port_statistics[portid].prev_rx_bytes;
        port_statistics[portid].prev_rx_bytes = cur_stat;

        cur_stat = port_statistics[portid].rx_packets;
        rx_packets_delta = cur_stat - port_statistics[portid].prev_rx_packets;
        port_statistics[portid].prev_rx_packets = cur_stat;

        cur_stat = port_statistics[portid].tx_bytes;
        tx_bytes_delta = cur_stat - port_statistics[portid].prev_tx_bytes;
        port_statistics[portid].prev_tx_bytes = cur_stat;

        cur_stat = port_statistics[portid].tx_packets;
        tx_packets_delta = cur_stat - port_statistics[portid].prev_tx_packets;
        port_statistics[portid].prev_tx_packets = cur_stat;

        printf("\n+------ Statistics for port %3lu -----------------------+"
               "\n| Packets sent: %38"PRIu64" |"
               "\n| Packets received: %34"PRIu64" |"
               "\n| Packet receive rate: %31.0f |"
               "\n| Packet send rate: %34.0f |"
               "\n| Bytes received: %36"PRIu64" |"
               "\n| Byte receive rate: %33.0f |"
               "\n| Packets dropped on send: %27"PRIu64" |"
               "\n| Packets dropped on receive: %24"PRIu64" |",
               /*(portid+port_gui_offset)*16 + 128,*/
               portid+port_gui_offset,
               port_statistics[portid].tx_packets,
               port_statistics[portid].rx_packets,
               (double)rx_packets_delta/(double)timer_period,
               (double)tx_packets_delta/(double)timer_period,
               port_statistics[portid].rx_bytes,
               (double)rx_bytes_delta/(double)timer_period,
               port_statistics[portid].tx_dropped,
               port_statistics[portid].rx_dropped);
        if (mode == MODE_BENCH) {
            printf("\n+------ Packet Generation -----------------------------+"
                   "\n| Short transmit bursts: %29"PRIu64" |"
                   "\n| Generate overrun: %34"PRIu64" |"
                   "\n| Allocation failures: %31"PRIu64" |",
                   port_statistics[portid].tx_short,
                   port_statistics[portid].tx_gen_overrun,
                   port_statistics[portid].tx_alloc_errors);
        }

        total_tx_packets_dropped += port_statistics[portid].tx_dropped;
        total_rx_packets_dropped += port_statistics[portid].rx_dropped;
        total_rx_packets_delta += rx_packets_delta;
        total_rx_bytes_delta += rx_bytes_delta;
        total_tx_packets_delta += tx_packets_delta;
        total_tx_bytes_delta += tx_bytes_delta;
        port_history[portid][histptr].tx_packets = port_statistics[portid].tx_packets;
        port_history[portid][histptr].rx_packets = port_statistics[portid].rx_packets;
        port_history[portid][histptr].rx_bytes = port_statistics[portid].rx_bytes;
        port_history[portid][histptr].tx_bytes = port_statistics[portid].tx_bytes;
        if (port_statistics[portid].rx_packets > 2) {
            port_history[portid][histptr].rx_mean_latency = port_statistics[portid].rx_mean_latency;
            port_history[portid][histptr].rx_var_latency = port_statistics[portid].rx_m2_latency /
                                                           (port_statistics[portid].rx_packets - 1);
        }
    }
    total_tx_packets += total_tx_packets_delta;
    total_tx_bytes += total_tx_bytes_delta;
    total_rx_bytes += total_rx_bytes_delta;
    total_rx_packets += total_rx_packets_delta;
    if (nb_ports_available > 1) {
        printf("\n+================= Aggregate statistics ===============+"
               "\n| Total packets sent: %32"PRIu64" |"
               "\n| Total packets received: %28"PRIu64" |"
               "\n| Total packet send rate: %28.0f |"
               "\n| Total packet receive rate: %25.0f |"
               "\n| Total bytes sent: %34"PRIu64" |"
               "\n| Total bytes received: %30"PRIu64" |"
               "\n| Total byte send rate: %30.0f |"
               "\n| Total byte receive rate: %27.0f |"
               "\n| Total packets dropped on send: %21"PRIu64" |"
               "\n| Total packets dropped on receive: %18"PRIu64" |",

               total_tx_packets,
               total_rx_packets,
               (double)total_tx_packets_delta/(double)timer_period,
               (double)total_rx_packets_delta/(double)timer_period,
               total_tx_bytes,
               total_rx_bytes,
               (double)total_tx_bytes_delta/(double)timer_period,
               (double)total_rx_bytes_delta/(double)timer_period,
               total_tx_packets_dropped,
               total_rx_packets_dropped);
    }
    printf("\n+======================================================+\n");
    epoch_history[histptr] = time(NULL);
    printf("Timestamp: %lld\n", (long long) epoch_history[histptr]);
    runtime_count += runtime_delta;
    if (runtime_count == 2) {
        tx_enable = 0;
    }
    histptr++;
    histptr = histptr % MAX_RUNTIME;
}

/* Send the burst of packets on an output interface */
static int send_burst(struct lcore_queue_conf *qconf, unsigned n, uint8_t port)
{
    struct rte_mbuf **m_table;
    unsigned ret;
    unsigned queueid =0;

    m_table = (struct rte_mbuf **)qconf->tx_mbufs[port].m_table;

    ret = rte_eth_tx_burst(port, (uint16_t) queueid, m_table, (uint16_t) n);
    port_statistics[port].tx_packets += ret;
    if (unlikely(ret < n)) {
        port_statistics[port].tx_dropped += (n - ret);
        do {
            rte_pktmbuf_free(m_table[ret]);
        } while (++ret < n);
    }

    return 0;
}

/* Enqueue packets for TX and prepare them to be sent */
static int send_packet(struct rte_mbuf *m, uint8_t port)
{
    unsigned lcore_id, len;
    struct lcore_queue_conf *qconf;

    lcore_id = rte_lcore_id();

    qconf = &lcore_queue_conf[lcore_id];
    len = qconf->tx_mbufs[port].len;
    qconf->tx_mbufs[port].m_table[len] = m;
    len++;

    /* enough pkts to be sent */
    if (unlikely(len == MAX_PKT_BURST)) {
        send_burst(qconf, MAX_PKT_BURST, port);
        len = 0;
    }

    qconf->tx_mbufs[port].len = len;
    return 0;
}

static void simple_echo(struct rte_mbuf *m, unsigned portid)
{
    struct ether_hdr *eth;
    struct ether_addr tmp;

    eth = rte_pktmbuf_mtod(m, struct ether_hdr *);

    /* swap src and dst ethernet address */
    /* Note: ether_addr_copy provided by DPDK is different from
       ether_addr_copy provided by the kernel. */
    ether_addr_copy(&eth->s_addr, &tmp);
    ether_addr_copy(&eth->d_addr, &eth->s_addr);
    ether_addr_copy(&tmp, &eth->d_addr);

    send_packet(m, (uint8_t) portid);
}

static void fhexdump(FILE* outfile, unsigned char *c, int len, int printascii)
{
    int i;
    unsigned char ascii[17];
    ascii[16] = '\0';

    for (i = 0; i < len; i++) {
        if ((i % 16) == 0) {
            if (i && printascii) {
                /* Print the _previous_ line's ASCII buffer*/
                fprintf(outfile, "  %s", ascii);
            }
            /* Print the offset */
            fprintf(outfile, "\n%04x ", i);
        }
        /* Print the hex code */
        fprintf(outfile, " %02x", c[i]);
        /* Append to the ASCII buffer */
        if (isprint(c[i])) {
            ascii[i % 16] = c[i];
        } else {
            ascii[i % 16] = '.';
        }
    }
    if (printascii) {
        ascii[(i % 16) + 1] = '\0';
        /* Pad the hex codes */
        while ((i % 16) != 0) {
            fprintf(outfile, "   ");
            i++;
        }
        fprintf(outfile, "  %s\n", ascii);
    } else {
        fprintf(outfile, "\n");
    }
}

static void simple_log(struct rte_mbuf *m, FILE* logfile)
{
    unsigned char* payload;
    uint32_t len;
    uint32_t usrhash;

    payload = rte_pktmbuf_mtod(m, unsigned char*);
    len = rte_pktmbuf_pkt_len(m);
    usrhash = m->hash.usr; /* could also be hash.rss */

    fprintf(logfile, "length: 0x%"PRIx32"\n", len);
    fprintf(logfile, "hash: 0x%"PRIx32, usrhash);
    fhexdump(logfile, payload, len, 0);
    fprintf(logfile, "\n");
    fflush(logfile);

    rte_pktmbuf_free(m);
}

static void simple_asymmetric(struct rte_mbuf *m, unsigned portid)
{
    if (portid != asymmetric_port) {
        send_packet(m, (uint8_t) asymmetric_port);
    } else {
        rte_pktmbuf_free(m);
    }
}

static void simple_forward(struct rte_mbuf *m, unsigned portid)
{
    unsigned dst_port;

    dst_port = dst_ports[portid];

    send_packet(m, (uint8_t) dst_port);
}

static void simple_drop(struct rte_mbuf *m)
{
    rte_pktmbuf_free(m);
}

#if CALCULATE_CHECKSUM
static inline uint16_t get_16b_sum(uint16_t *ptr16, uint32_t nr)
{
    int32_t sum = 0;
    while (nr > 1) {
        sum +=*ptr16;
        nr -= sizeof(uint16_t);
        ptr16++;
        if (sum > UINT16_MAX)
            sum -= UINT16_MAX;
    }

    /* If length is in odd bytes */
    if (nr)
        sum += *((uint8_t*)ptr16);

        sum = ((sum & 0xffff0000) >> 16) + (sum & 0xffff);
        sum &= 0x0ffff;
        return (uint16_t)sum;
}

static inline uint16_t get_ipv4_cksum(struct ipv4_hdr *ipv4_hdr)
{
    uint16_t cksum;
    cksum = get_16b_sum((uint16_t*)ipv4_hdr, sizeof(struct ipv4_hdr));
    return (uint16_t)((cksum == 0xffff)?cksum:~cksum);
}
#endif

/* Fill up an mbuf with a packet.
 */
static void build_frame(struct rte_mbuf *m, uint32_t req_sz, uint32_t flowid,
            uint32_t streamid, uint32_t port_num)
{
    struct ether_hdr *eth;
    struct ipv4_hdr *ip;
    struct udp_hdr *udp;
    char *pkt;

    uint32_t frame_sz;
    uint16_t iplen, udplen;
#if !SKIP_PAYLOAD
    uint16_t paylen;
    uint32_t cur_seg_data;
    int l, l0;
#endif

    uint64_t base_eth;
    int i;

    struct ether_addr eth_src;
    struct ether_addr eth_dst;

    base_eth = eth_src_base + port_num;

    for (i = ETHER_ADDR_LEN - 1; i >= 0; i--) {
        eth_src.addr_bytes[i] = base_eth & 0xff;
        base_eth >>= 8;
    }

    base_eth = eth_dst_base + eth_stride*streamid + flowid;

    for (i = ETHER_ADDR_LEN - 1; i >= 0; i--) {
        eth_dst.addr_bytes[i] = base_eth & 0xff;
        base_eth >>= 8;
    }

    /* FCS is 4 bytes */
    frame_sz = req_sz - 4;

    m->pkt_len = (uint16_t)frame_sz;
    if (frame_sz > max_seg_len)
        m->data_len = (uint16_t)max_seg_len;
    else
        m->data_len = (uint16_t)frame_sz;

    pkt = rte_pktmbuf_mtod(m, char *);
    eth = (struct ether_hdr *)pkt;
    pkt += sizeof(struct ether_hdr);
    ip = (struct ipv4_hdr *)pkt;
    pkt += sizeof(struct ipv4_hdr);
    udp = (struct udp_hdr *)pkt;
    pkt += sizeof(struct udp_hdr);
    iplen = frame_sz - sizeof(*eth);
    udplen = iplen - sizeof(*ip);

    ether_addr_copy(&eth_dst, &eth->d_addr);
    ether_addr_copy(&eth_src, &eth->s_addr);
    eth->ether_type = rte_cpu_to_be_16(ETHER_TYPE_IPv4);

    ip->version_ihl = IP_VHL_DEF;
    ip->type_of_service = 0;
    ip->total_length = rte_cpu_to_be_16(iplen);
    ip->packet_id = 0;

    ip->fragment_offset = 0;
    ip->time_to_live   = IP_DEFTTL;
    ip->next_proto_id = IPPROTO_UDP;

    ip->src_addr = rte_cpu_to_be_32(ip_src_base + port_num);
    ip->dst_addr = rte_cpu_to_be_32(ip_dst_base + ip_stride*streamid + flowid);

#if CALCULATE_CHECKSUM
    ip->hdr_checksum = get_ipv4_cksum(ip);
#else
    ip->hdr_checksum = 0;
#endif

    udp->src_port = rte_cpu_to_be_16(2048);
    udp->dst_port = rte_cpu_to_be_16(4096);
    udp->dgram_len = rte_cpu_to_be_16(udplen);


    *(uint32_t *)pkt = flowid;
    *(uint32_t *)(pkt + 4) = streamid;
#if SKIP_PAYLOAD
#if (MAGIC_MATCH == 4)
    *(uint32_t *)(pkt + 8) = *(const uint32_t *)default_payload;
#else
    bcopy(default_payload, pkt + 8, strlen(default_payload));
#endif
#else
    paylen = udplen - sizeof(*udp);
    i = 8;
    l = 0;
    l0 = strlen(default_payload);
    cur_seg_data = sizeof(*eth) + sizeof(*ip) + sizeof(*udp) + 8;
    while ((cur_seg_data < max_seg_len) && paylen) {
        l = RTE_MIN(l0, (int)(max_seg_len - cur_seg_data));
        l = RTE_MIN(l, paylen);
        bcopy(default_payload, pkt + i, l);
        i += l;
        paylen -= l;
        cur_seg_data += l;
    }

    m->data_len = cur_seg_data - 8;
#endif
}

/* fetch timestamp from mbuf and calculate latency
 */
static uint64_t get_latency(struct rte_mbuf *m, uint64_t curr_time)
{
    char *pkt;

    uint32_t hdrlen;
    uint64_t timestamp;

    pkt = rte_pktmbuf_mtod(m, char *);
    hdrlen = sizeof(struct ether_hdr) +
             sizeof(struct ipv4_hdr) +
             sizeof(struct udp_hdr);
    pkt += hdrlen;

    /*memcpy(&timestamp, pkt, sizeof(timestamp));*/
    timestamp = *((uint64_t*)pkt);
    pkt += sizeof(timestamp);
#if MAGIC_MATCH == 4
    if (*(uint32_t *)pkt == *(const uint32_t *)default_payload) {
#else
    if (memcmp(pkt, default_payload, MAGIC_MATCH) == 0) {
#endif
        return curr_time - timestamp;
    } else {
        return 0;
    }
}

/* Update mbuf with timestamp
 */
static void update_timestamp(struct rte_mbuf *m, uint64_t timestamp)
{
    char *pkt;

    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
    pkt = rte_pktmbuf_mtod(m, char *);
    pkt += sizeof(struct ether_hdr);
    pkt += sizeof(struct ipv4_hdr);
    pkt += sizeof(struct udp_hdr);
    memcpy(pkt, &timestamp, sizeof(timestamp));
}

/* Selects randomly between packet sizes of 64, 570 and 1514 */
/* proportional to 7:4:1 to simulate IMIX traffic */
static uint32_t imix_size(void)
{
    uint64_t random;
    random = rte_rand() % 120;
    if (random < 10) /* 1 in 12 */
        return 1518;
    if (random < 50) /* 4 in 12 */
        return 574;
    return 68;       /* 7 in 12 */
}

/* main processing loop */
static void main_loop(void)
{
    struct rte_mbuf *pkts_burst[MAX_PKT_BURST];
    struct rte_mbuf *m;
    unsigned lcore_id;
    uint64_t prev_tsc, diff_tsc, cur_tsc, timer_tsc, prev_timer_tsc;
    unsigned i, j, portid, nb_rx, nb_tx;
    struct lcore_queue_conf *qconf;
    const uint64_t drain_tsc = (rte_get_tsc_hz() + US_PER_S - 1) /
                               US_PER_S * BURST_TX_DRAIN_US;
    struct rte_mbuf *tx_burst[MAX_TX_BURST_SIZE];
    int tx_size[MAX_TX_BURST_SIZE];
    uint64_t counter;
    uint32_t flowid;
    uint32_t streamid;
    struct rte_mbuf *tx_packet;
    uint32_t size;
    uint32_t allocated_mbufs;
    uint64_t timestamp;
    uint64_t txdelta;
    double latency;
    double latency_delta;
#if !FAST_GEN
    uint64_t total_flows;
    total_flows = number_of_streams * flows_per_stream * burst_per_stream;
#endif
    txdelta = 0;
    prev_tsc = 0;
    timer_tsc = 0;
    prev_timer_tsc = 0;
    counter = 0;
    allocated_mbufs = 0;
    size = pkt_size;

    lcore_id = rte_lcore_id();
    qconf = &lcore_queue_conf[lcore_id];

    if (qconf->n_rx_port == 0 && qconf->n_tx_port == 0) {
        RTE_LOG(INFO, TRAFGEN, "lcore %u has nothing to do\n", lcore_id);
        return;
    }

    RTE_LOG(INFO, TRAFGEN, "entering main loop on lcore %u\n", lcore_id);

    for (i = 0; i < qconf->n_rx_port; i++) {

        portid = qconf->rx_port_list[i];
        RTE_LOG(INFO, TRAFGEN, " -- rx lcoreid=%u portid=%u\n", lcore_id,
            portid);
    }

    for (i = 0; i < qconf->n_tx_port; i++) {
        portid = qconf->tx_port_list[i];
        RTE_LOG(INFO, TRAFGEN, " -- tx lcoreid=%u portid=%u\n", lcore_id,
            portid);
        if (tx_pps) {
            txdelta = (rte_get_tsc_hz()/tx_pps)*tx_burst_size;
        }
        RTE_LOG(INFO, TRAFGEN, "TSC delta between TX bursts: %ld\n", txdelta);
    }

    while (runtime_count > 0) {

        cur_tsc = rte_rdtsc();
        diff_tsc = cur_tsc - prev_tsc;

        /* XXX: This only supports one TX queue per lcore... */
        if (qconf->n_tx_port) {

            portid = qconf->tx_port_list[0];
#if 0
            if (assert_burst(tx_burst, allocated_mbufs)) {
                fprintf(stderr, "tx_burst assert tripped at %d\n", __LINE__);
            }
#endif
            /* This lcore is TX only */
            if (tx_enable && (diff_tsc > txdelta)) {
                if (unlikely(allocated_mbufs < tx_burst_size)) {
                    /* It's time to transmit, but we haven't generated
                       enough packets! */
                    port_statistics[portid].tx_gen_overrun++;
                } else {
                    port_statistics[portid].tx_bursts++;
                    timestamp = rte_get_timer_cycles();
                    for (i = 0; i < tx_burst_size; i++) {
                        update_timestamp(tx_burst[i], timestamp);
                    }
                    nb_tx = rte_eth_tx_burst(portid, (uint16_t) 0/*queueid*/,
                                             tx_burst, tx_burst_size);
                    port_statistics[portid].tx_packets += nb_tx;
                    for (i = 0; i < nb_tx; i++) {
                        port_statistics[portid].tx_bytes += tx_size[i];
                    }
                    if (nb_tx < tx_burst_size) {
                       port_statistics[portid].tx_short++;
                    }
                    allocated_mbufs -= nb_tx;
                    memmove(tx_burst, tx_burst + nb_tx,
                            allocated_mbufs * sizeof(*tx_burst));
                    memmove(tx_size, tx_size + nb_tx,
                            allocated_mbufs * sizeof(*tx_size));
                    prev_tsc = cur_tsc;
                }
            }

            while (allocated_mbufs < MAX_TX_BURST_SIZE) {
                tx_packet = rte_pktmbuf_alloc(pktmbuf_pool);
                if (tx_packet == NULL) {
                    /* Allocation failure, but we might still have some
                       mbufs left in the tx_burst buffer... */
                    rte_delay_us(10);
                    port_statistics[portid].tx_alloc_errors++;
                    break;
                }
#if FAST_GEN
                flowid = counter & (64-1); /* % 64 */
                streamid = counter >> 12; /* / (64*64) */
#else
                flowid = counter % flows_per_stream;
                streamid = counter / (flows_per_stream * burst_per_stream);
#endif
                if (!pkt_size) {
                    size = imix_size();
                }
                build_frame(tx_packet, size, flowid, streamid, portid);
                counter++;
#if FAST_GEN
                counter = counter & ((64*64*64)-1); /* % (64*64*64) */
#else
                counter = counter % total_flows;
#endif
                tx_burst[allocated_mbufs] = tx_packet;
                tx_size[allocated_mbufs] = size;
                allocated_mbufs++;
            }

            /* Statistics loop */
            if (timer_period > 0) {
                /* do this only on master core */
                if (lcore_id == rte_get_master_lcore()) {
                    /* advance the timer */
                    timer_tsc = cur_tsc - prev_timer_tsc;
                    /* if timer has reached its timeout */
                    if (unlikely(timer_tsc >= tsc_100hz)) {
                        rte_timer_manage();
                        /*print_stats();*/
                        /* reset the timer */
                        prev_timer_tsc = cur_tsc;
                    }
                }
            }
            continue;
        }
        /*
         * TX burst queue drain
         */
        if (unlikely(diff_tsc > drain_tsc)) {

            for (portid = 0; portid < RTE_MAX_ETHPORTS; portid++) {
                if (qconf->tx_mbufs[portid].len == 0)
                    continue;
                send_burst(&lcore_queue_conf[lcore_id],
                         qconf->tx_mbufs[portid].len,
                         (uint8_t) portid);
                qconf->tx_mbufs[portid].len = 0;
            }

            prev_tsc = cur_tsc;
        }

        /* Statistics loop */
        if (timer_period > 0) {
            /* do this only on master core */
            if (lcore_id == rte_get_master_lcore()) {
                /* advance the timer */
                timer_tsc = cur_tsc - prev_timer_tsc;
                /* if timer has reached its timeout */
                if (unlikely(timer_tsc >= tsc_100hz)) {
                    rte_timer_manage();
                    /*print_stats();*/
                    /* reset the timer */
                    prev_timer_tsc = cur_tsc;
                }
            }
        }

        /*
         * Read packet from RX queues
         */
        for (i = 0; i < qconf->n_rx_port; i++) {

            portid = qconf->rx_port_list[i];
            nb_rx = rte_eth_rx_burst((uint8_t) portid, 0,
                         pkts_burst, MAX_PKT_BURST);

            /* Technically, this branch only needs to be taken once. In a
               real-world application, only one mode is typically used. */
            switch (mode) {
            case MODE_LOG:
                port_statistics[portid].rx_packets += nb_rx;
                port_statistics[portid].rx_dropped += nb_rx;
                for (j = 0; j < nb_rx; j++) {
                    m = pkts_burst[j];
                    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
                    port_statistics[portid].rx_bytes += rte_pktmbuf_pkt_len(m);
                    simple_log(m, log_files[portid]);
                }
                break;
            case MODE_DROP:
                port_statistics[portid].rx_packets += nb_rx;
                port_statistics[portid].rx_dropped += nb_rx;
                for (j = 0; j < nb_rx; j++) {
                    m = pkts_burst[j];
                    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
                    port_statistics[portid].rx_bytes += rte_pktmbuf_pkt_len(m);
                    simple_drop(m);
                }
                break;
            case MODE_BENCH:
                timestamp = rte_get_timer_cycles();
                port_statistics[portid].rx_dropped += nb_rx;
                for (j = 0; j < nb_rx; j++) {
                    m = pkts_burst[j];
                    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
                    port_statistics[portid].rx_bytes += rte_pktmbuf_pkt_len(m);
                    latency = (double)get_latency(m, timestamp) / (double)timer_hz;
                    port_statistics[portid].rx_packets++;
                    latency_delta = latency - port_statistics[portid].rx_mean_latency;
                    port_statistics[portid].rx_mean_latency += latency_delta /
                                                               (double)port_statistics[portid].rx_packets;
                    port_statistics[portid].rx_m2_latency += latency_delta *
                                                             (latency - (double)port_statistics[portid].rx_mean_latency);
                    simple_drop(m);
                }
                break;
            case MODE_ECHO:
                port_statistics[portid].rx_packets += nb_rx;
                for (j = 0; j < nb_rx; j++) {
                    m = pkts_burst[j];
                    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
                    port_statistics[portid].rx_bytes += rte_pktmbuf_pkt_len(m);
                    simple_echo(m, portid);
                }
                break;
            case MODE_ASYMMETRIC:
                port_statistics[portid].rx_packets += nb_rx;
                for (j = 0; j < nb_rx; j++) {
                    m = pkts_burst[j];
                    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
                    port_statistics[portid].rx_bytes += rte_pktmbuf_pkt_len(m);
                    simple_asymmetric(m, portid);
                }
                break;
            case MODE_FWD:
            default:
                port_statistics[portid].rx_packets += nb_rx;
                for (j = 0; j < nb_rx; j++) {
                    m = pkts_burst[j];
                    rte_prefetch0(rte_pktmbuf_mtod(m, void *));
                    port_statistics[portid].rx_bytes += rte_pktmbuf_pkt_len(m);
                    simple_forward(m, portid);
                }
                break;
            }
        }
    }
}

static int launch_one_lcore(__attribute__((unused)) void *dummy)
{
    /* This is where the branch can be taken for the different modes */
    main_loop();
    return 0;
}

static int parse_portmask(const char *portmask_arg)
{
    char *end = NULL;
    unsigned long pm;

    /* parse hexadecimal string */
    pm = strtoul(portmask_arg, &end, 16);
    if ((portmask_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return -1;

    if (pm == 0)
        return -1;

    return pm;
}

static unsigned long int parse_offset(const char *offset_arg)
{
    char *end = NULL;
    unsigned long int n;

    /* parse hexadecimal string */
    n = strtoul(offset_arg, &end, 10);
    if ((offset_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return 0;
    return n;
}

static unsigned int parse_nqueue(const char *nq_arg)
{
    char *end = NULL;
    unsigned long n;

    /* parse hexadecimal string */
    n = strtoul(nq_arg, &end, 10);
    if ((nq_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return 0;
    if (n == 0)
        return 0;
    if (n >= MAX_RX_QUEUE_PER_LCORE)
        return 0;

    return n;
}

static void parse_summary_fname(const char *fname_arg)
{
    strncpy(summary_fname, fname_arg, MAX_FNAME_LEN);
    summary_fname[MAX_FNAME_LEN] = '\0';
}

static int parse_timer_period(const char *period_arg)
{
    char *end = NULL;
    int n;

    /* parse number string */
    n = strtol(period_arg, &end, 0);
    if ((period_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return -1;
    if (n >= MAX_TIMER_PERIOD)
        return -1;

    return n;
}

static long int parse_long(const char *long_arg)
{
    char *end = NULL;
    long int n;

    if (long_arg[0] == '\0')
        return -1;
    /* parse number string */
    n = strtol(long_arg, &end, 0);
    if (end == NULL)
        return -1;
    if ((*end == 'k') && (*(end + 1) == '\0'))
        return n*1000;
    if ((*end == 'M') && (*(end + 1) == '\0'))
        return n*1000000L;
    if (*end != '\0')
        return -1;
    return n;
}

static long long int
formatted_mac_to_lli(const char *mac) {
    long long int mac_int;
    int values[6];
    int i;
    char junk;

    if (6 == sscanf(mac, "%x:%x:%x:%x:%x:%x%c",
        &values[0], &values[1], &values[2],
        &values[3], &values[4], &values[5],
        &junk)) {
        mac_int = 0;
        for (i = 0; i < 6; i++) {
            if (values[i] > 0xff || values[i] < 0) {
                return -1;
            }
            mac_int <<= 8;
            mac_int |= (uint8_t) values[i];
        }
    } else {
        return -1;
    }
    return mac_int;
}

static long long int
formatted_ip4_to_lli(const char *addr) {
    unsigned char buf[sizeof(struct in_addr)];
    int i;
    long long int ip_int;

    if (inet_pton(AF_INET, addr, buf) <= 0) {
        return -1;
    }
    ip_int = 0;
    for (i = 0; i < 4; i++) {
        ip_int <<= 8;
        ip_int |= (uint8_t) buf[i];
    }
    return ip_int;
}

static long long int parse_ip4_addr(const char *ip4_arg)
{
    char *end = NULL;
    long long int n;

    /* try to parse a.b.c.d first */
    n = formatted_ip4_to_lli(ip4_arg);
    if (n >= 0) {
        return n;
    }

    /* parse arbitrary number string */
    n = strtoll(ip4_arg, &end, 0);
    if ((ip4_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return -1;

    return n;
}

static long long int parse_eth_addr(const char *mac_arg)
{
    char *end = NULL;
    long long int n;

    /* try to parse aa:bb:cc:dd:ee:ff first */
    n = formatted_mac_to_lli(mac_arg);
    if (n >= 0) {
        return n;
    }

    /* parse arbitrary number string */
    n = strtoll(mac_arg, &end, 0);
    if ((mac_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return -1;

    return n;
}

static int parse_runtime_count(const char *runtime_arg)
{
    char *end = NULL;
    int n;

    /* parse number string */
    n = strtol(runtime_arg, &end, 0);
    if ((runtime_arg[0] == '\0') || (end == NULL) || (*end != '\0'))
        return -1;
    if (n >= MAX_RUNTIME)
        return -1;

    return n;
}

static struct option lgopts[] =
{
    {"portmask", required_argument, NULL, 'p'},
    {"benchmark", no_argument, NULL, 'b'},
    {"forward", no_argument, NULL, 'f'},
    {"echo", no_argument, NULL, 'e'},
    {"log", no_argument, NULL, 'l'},
    {"asymmetric", no_argument, NULL, 'a'},

    {"queues-per-lcore", required_argument, NULL, 'q'},
    {"stats-period", required_argument, NULL, 'T'},
    {"runtime", required_argument, NULL, 'Q'},
    {"summary", required_argument, NULL, 's'},
    {"src-ip", required_argument, NULL, 'u'},
    {"dst-ip", required_argument, NULL, 'v'},
    {"ip-stride", required_argument, NULL, 'k'},
    {"src-mac", required_argument, NULL, 'w'},
    {"dst-mac", required_argument, NULL, 'x'},
    {"mac-stride", required_argument, NULL, 'g'},
    {"streams", required_argument, NULL, 'i'},
    {"flows-per-stream", required_argument, NULL, 'y'},
    {"bursts-per-stream", required_argument, NULL, 'j'},
    {"packet-size", required_argument, NULL, 'z'},
    {"tx-burst", required_argument, NULL, 't'},
    {"pps", required_argument, NULL, 'r'},

    {NULL, 0, NULL, 0}
};

/* display usage */
static void usage(const char *prgname)
{
    printf("%s [EAL options] -- [APP options]\n"
           "Mandatory APP arguments: \n"
           "  --portmask|-p PORTMASK: hexadecimal bitmask of ports to use\n"
           "APP mode select. Default is drop, or select one of the following:\n"
           "  --benchmark|-b: Benchmark mode (transmit, drop and summarize)\n"
           "  --forward|-f: Forward packets unmodified\n"
           "  --echo|-e: Echo packets with src and dst mac swapped\n"
           "  --log|-l: Log and drop packets to trafgen.pX.log"
               " (where X is the port)\n"
           "  --asymmetric|-a: Forward packets to the highest-numbered port\n"
           "Optional APP arguments:\n"
           "  --queues-per-lcore|-q NQ: number of queue (=ports) per lcore"
               " (default 1)\n"
           "  --stats-period|-T PERIOD: statistics will be refreshed each"
               " PERIOD seconds"
               " (0 to disable, default 1, 86400 maximum)\n"
           "  --runtime|-Q COUNT: quit after COUNT periods,"
               " 0 to disable (default)\n"
           "  --summary|-s SUMMARY.TXT: save the summary statistics to a file\n"
           "  --src-ip|-u SRC_IP: base source IP address\n"
           "  --dst-ip|-v DST_IP: base destination IP address\n"
           "  --ip-stride|-k IP_STRIDE: IP stride between streams"
               " (default 1.0.0.0)\n"
           "  --src-mac|-w SRC_MAC: base source MAC address\n"
           "  --dst-mac|-x DST_MAC: base destination MAC address\n"
           "  --mac-stride|-g MAC_STRIDE: MAC stride between streams "
           "(default 01:00:00:00:00:00)\n"
           "  --streams|-i NUM_STREAMS: number of streams (default 1)\n"
           "  --flows-per-stream|-y NUM_FLOWS: flows per stream"
               " (default 65536)\n"
           "  --bursts-per-stream|-j NUM_BURSTS: number of bursts per stream"
               " (default 1)\n"
           "  --packet-size|-z PKT_SIZE: packet size (0 for IMIX, default 64)\n"
           "  --tx-burst|-t TX_BURST_SIZE: TX burst size (default 32)\n"
           "  --pps|-r TX_PPS: TX packet rate to attempt (default 0)\n",
           prgname);
}

/* Parse the argument given in the command line of the application */
static int parse_args(int argc, char **argv)
{
    long long int param;
    int opt, ret;
    char **argvopt;
    int option_index;
    char *prgname = argv[0];

    argvopt = argv;

    while ((opt = getopt_long(argc, argvopt,
                  "t:r:i:j:k:g:u:v:w:x:y:z:o:p:q:T:Q:s:felb",
                  lgopts, &option_index)) != EOF) {

        switch (opt) {
        /* offset */
        case 'o':
            port_gui_offset = parse_offset(optarg);
            break;

        /* portmask */
        case 'p':
            enabled_port_mask = parse_portmask(optarg);
            if (enabled_port_mask == 0) {
                printf("invalid portmask\n");
                usage(prgname);
                return -1;
            }
            break;

        /* logfile */
        case 's':
            parse_summary_fname(optarg);
            break;

        /* nqueue */
        case 'q':
            rx_queue_per_lcore = parse_nqueue(optarg);
            if (rx_queue_per_lcore == 0) {
                printf("invalid queue number\n");
                usage(prgname);
                return -1;
            }
            tx_queue_per_lcore = rx_queue_per_lcore;
            break;

        /* src ip */
        case 'u':
            param = parse_ip4_addr(optarg);
            if (param < 0) {
                printf("invalid source IP address\n");
                usage(prgname);
                return -1;
            }
            ip_src_base = param;
            break;

        /* dst ip */
        case 'v':
            param = parse_ip4_addr(optarg);
            if (param < 0) {
                printf("invalid destination IP address\n");
                usage(prgname);
                return -1;
            }
            ip_dst_base = param;
            break;

        /* ip stride */
        case 'k':
            param = parse_ip4_addr(optarg);
            if (param < 0) {
                printf("invalid IP stride\n");
                usage(prgname);
                return -1;
            }
            ip_stride = param;
            break;

        /* src eth */
        case 'w':
            param = parse_eth_addr(optarg);
            if (param < 0) {
                printf("invalid source eth address\n");
                usage(prgname);
                return -1;
            }
            eth_src_base = param;
            break;

        /* dst eth */
        case 'x':
            param = parse_eth_addr(optarg);
            if (param < 0) {
                printf("invalid destination eth address\n");
                usage(prgname);
                return -1;
            }
            eth_dst_base = param;
            break;

        /* eth stride */
        case 'g':
            param = parse_eth_addr(optarg);
            if (param < 0) {
                printf("invalid eth stride\n");
                usage(prgname);
                return -1;
            }
            eth_stride = param;
            break;

        /* flows_per_stream */
        case 'y':
            param = parse_long(optarg);
            if (param < 0) {
                printf("invalid number of flows per stream\n");
                usage(prgname);
                return -1;
            }
            flows_per_stream = param;
            break;

        /* number_of_streams */
        case 'i':
            param = parse_long(optarg);
            if (param < 0) {
                printf("invalid number of streams\n");
                usage(prgname);
                return -1;
            }
            number_of_streams = param;
            break;

        /* burst_per_stream */
        case 'j':
            param = parse_long(optarg);
            if (param < 0) {
                printf("invalid number of bursts per stream\n");
                usage(prgname);
                return -1;
            }
            burst_per_stream = param;
            break;

        /* pkt_size */
        case 'z':
            param = parse_long(optarg);
            if (param == 0) {
                pkt_size = 0;
                break;
            }
            if (param < 64 || param > 1514) {
                printf("invalid packet size\n");
                usage(prgname);
                return -1;
            }
            pkt_size = param + 4;
            break;

        /* tx_burst_size */
        case 't':
            param = parse_long(optarg);
            if (param < MIN_TX_BURST_SIZE || param > MAX_TX_BURST_SIZE ) {
                printf("invalid burst size\n");
                usage(prgname);
                return -1;
            }
            tx_burst_size = param;
            break;

        /* tx_pps */
        case 'r':
            param = parse_long(optarg);
            if (param < 0) {
                printf("invalid packet rate\n");
                usage(prgname);
                return -1;
            }
            tx_pps = param;
            break;

        /* timer period */
        case 'T':
            timer_period = parse_timer_period(optarg);
            if (timer_period < 0) {
                printf("invalid timer period\n");
                usage(prgname);
                return -1;
            }
            break;

        /* runtime count */
        case 'Q':
            runtime_count = parse_runtime_count(optarg);
            if (runtime_count < 0) {
                printf("invalid runtime count\n");
                usage(prgname);
                return -1;
            }
            if (runtime_count == 0) {
                runtime_delta = 0;
            } else {
                runtime_delta = -1;
            }
            break;

        /* benchmark */
        case 'b':
            mode = MODE_BENCH;
            break;

        /* forward traffic */
        case 'f':
            mode = MODE_FWD;
            break;

        /* echo traffic */
        case 'e':
            mode = MODE_ECHO;
            break;

        /* asymmetric mode */
        case 'a':
            mode = MODE_ASYMMETRIC;
            break;

        /* log traffic */
        case 'l':
            port_conf.rxmode.mq_mode = ETH_MQ_RX_RSS; /**< Enable RSS on RX */
            mode = MODE_LOG;
            break;

        /* long options */
        case 0:
            usage(prgname);
            return -1;

        default:
            usage(prgname);
            return -1;
        }
    }

    if (optind >= 0)
        argv[optind-1] = prgname;

    ret = optind-1;
    optind = 0; /* reset getopt lib */
    return ret;
}

/* Check the link status of all ports in up to 9s, and print them finally */
static void check_all_ports_link_status(uint8_t port_num, uint32_t port_mask)
{
#define CHECK_INTERVAL 100 /* 100ms */
#define MAX_CHECK_TIME 90 /* 9s (90 * 100ms) in total */
    uint8_t portid, count, all_ports_up, print_flag = 0;
    struct rte_eth_link link;

    printf("\nChecking link status");
    fflush(stdout);
    for (count = 0; count <= MAX_CHECK_TIME; count++) {
        all_ports_up = 1;
        for (portid = 0; portid < port_num; portid++) {
            if ((port_mask & (1 << portid)) == 0)
                continue;
            memset(&link, 0, sizeof(link));
            rte_eth_link_get_nowait(portid, &link);
            /* print link status if flag set */
            if (print_flag == 1) {
                if (link.link_status)
                    printf("Port %d Link Up - speed %u "
                        "Mbps - %s\n", (uint8_t)portid,
                        (unsigned)link.link_speed,
                (link.link_duplex == ETH_LINK_FULL_DUPLEX) ?
                    ("full-duplex") : ("half-duplex\n"));
                else
                    printf("Port %d Link Down\n",
                        (uint8_t)portid);
                continue;
            }
            /* clear all_ports_up flag if any link down */
            if (link.link_status == 0) {
                all_ports_up = 0;
                break;
            }
        }
        /* after finally printing all link status, get out */
        if (print_flag == 1)
            break;

        if (all_ports_up == 0) {
            printf(".");
            fflush(stdout);
            rte_delay_ms(CHECK_INTERVAL);
        }

        /* set the print_flag if all ports up or timeout */
        if (all_ports_up == 1 || count == (MAX_CHECK_TIME - 1)) {
            print_flag = 1;
            printf("done\n");
        }
    }
}

static void update_stats(void)
{
    int i;
    FILE* fsummary;
    uint8_t portid;

    if (summary_fname[0]) {
        fsummary = fopen(summary_fname,"w");
    } else {
        fsummary = stdout;
    }

    fprintf(fsummary, "timestamps:");
    for (i = 0; i < histptr; i++) {
        fprintf(fsummary, " %lld", (long long) epoch_history[i]);
    }
    fprintf(fsummary, "\n");
    for (portid = 0; portid < RTE_MAX_ETHPORTS; portid++) {
        /* skip disabled ports */
        if ((enabled_port_mask & (1 << portid)) == 0)
            continue;
        fprintf(fsummary, "port%d.rx_packets:", portid);
        for (i = 0; i < histptr; i++) {
            fprintf(fsummary, " %"PRIu64, port_history[portid][i].rx_packets);
        }
        fprintf(fsummary, "\n");
        fprintf(fsummary, "port%d.rx_bytes:", portid);
        for (i = 0; i < histptr; i++) {
            fprintf(fsummary, " %"PRIu64, port_history[portid][i].rx_bytes);
        }
        fprintf(fsummary, "\n");
        fprintf(fsummary, "port%d.tx_packets:", portid);
        for (i = 0; i < histptr; i++) {
            fprintf(fsummary, " %"PRIu64, port_history[portid][i].tx_packets);
        }
        fprintf(fsummary, "\n");
        fprintf(fsummary, "port%d.tx_bytes:", portid);
        for (i = 0; i < histptr; i++) {
            fprintf(fsummary, " %"PRIu64, port_history[portid][i].tx_bytes);
        }
        fprintf(fsummary, "\n");
        if (mode != MODE_BENCH) {
            continue;
        }
        fprintf(fsummary, "port%d.rx_mean_latency:", portid);
        for (i = 0; i < histptr; i++) {
            fprintf(fsummary, " %f", port_history[portid][i].rx_mean_latency*1000000.0);
        }
        fprintf(fsummary, "\n");
        fprintf(fsummary, "port%d.rx_std_latency:", portid);
        for (i = 0; i < histptr; i++) {
            fprintf(fsummary, " %f", sqrt(port_history[portid][i].rx_var_latency)*1000000.0);
        }
        fprintf(fsummary, "\n");
    }
    if (summary_fname[0]) {
        fclose(fsummary);
    }
}

static void handle_signals(int signum)
{
    switch (signum) {
    case SIGHUP:
    case SIGINT:
    case SIGTERM:
        runtime_count = 0;
        break;
    case SIGUSR1:
        update_stats();
        break;
    }
}

int main(int argc, char **argv)
{
    struct lcore_queue_conf *qconf;
    struct rte_eth_dev_info dev_info;
    int ret;
    uint8_t nb_ports;
    uint8_t portid, last_port;
    unsigned lcore_id, rx_lcore_id;
    unsigned nb_ports_in_mask = 0;
    char logname[255];
    void *mbuf_data_room = (void *)MBUF_DATA_ROOM;

    printf("%s version %s\n", argv[0], VERSION);
    summary_fname[0] = '\0';

    rte_set_application_usage_hook(usage);
    /* init EAL */
    ret = rte_eal_init(argc, argv);
    if (ret < 0)
        rte_exit(EXIT_FAILURE, "Invalid EAL arguments\n");

    rte_timer_subsystem_init();
    /* init timer structures */
    rte_timer_init(&print_stats_timer);
    timer_hz = rte_get_timer_hz();

    tsc_100hz = rte_get_tsc_hz() / 100;

    argc -= ret;
    argv += ret;

    /* parse application arguments (after the EAL ones) */
    ret = parse_args(argc, argv);
    if (ret < 0)
        rte_exit(EXIT_FAILURE, "Invalid TRAFGEN arguments\n");

    /* create the mbuf pool */
    pktmbuf_pool = rte_mempool_create("mbuf_pool", NB_MBUF,
                   MBUF_SIZE, 64,
                   sizeof(struct rte_pktmbuf_pool_private),
                   rte_pktmbuf_pool_init, mbuf_data_room,
                   rte_pktmbuf_init, NULL,
                   rte_socket_id(), 0);
    if (pktmbuf_pool == NULL)
        rte_exit(EXIT_FAILURE, "Cannot init mbuf pool\n");

    nb_ports = rte_eth_dev_count();
    if (nb_ports == 0)
        rte_exit(EXIT_FAILURE, "No Ethernet ports - bye\n");

    if (nb_ports > RTE_MAX_ETHPORTS)
        nb_ports = RTE_MAX_ETHPORTS;

    /* reset dst_ports */
    for (portid = 0; portid < RTE_MAX_ETHPORTS; portid++)
        dst_ports[portid] = 0;
    last_port = 0;

    /*
     * Set up the forwarding map: odd and even cores forward
     * to each other.
     */
    for (portid = 0; portid < nb_ports; portid++) {
        /* skip ports that are not enabled */
        if ((enabled_port_mask & (1 << portid)) == 0)
            continue;

        if (nb_ports_in_mask % 2) {
            dst_ports[portid] = last_port;
            dst_ports[last_port] = portid;
        }
        else
            last_port = portid;

        nb_ports_in_mask++;

        rte_eth_dev_info_get(portid, &dev_info);
        if (mode == MODE_LOG) {
            sprintf(logname, "trafgen.p%d.log", portid);
            log_files[portid] = fopen(logname, "w");
        }
    }
    asymmetric_port = portid;

    if (nb_ports_in_mask % 2) {
        if (mode == MODE_FWD) {
            printf("Notice: odd number of ports in portmask.\n");
        }
        dst_ports[last_port] = last_port;
    }

    /* Initialize the port/queue configuration of each logical core */
    switch (mode) {
    case MODE_BENCH:
        /* Allocate TX lcores for each port first. */
        lcore_id = 0;
        qconf = NULL;
        for (portid = 0; portid < nb_ports; portid++) {
            /* skip ports that are not enabled */
            if ((enabled_port_mask & (1 << portid)) == 0)
                continue;

            /* get the lcore_id for this port */
            while (rte_lcore_is_enabled(lcore_id) == 0 ||
                   lcore_queue_conf[lcore_id].n_tx_port ==
                   tx_queue_per_lcore) {
                lcore_id++;
                if (lcore_id >= RTE_MAX_LCORE)
                    rte_exit(EXIT_FAILURE, "Not enough cores\n");
            }

            if (qconf != &lcore_queue_conf[lcore_id])
                /* Assigned a new logical core in the loop above. */
                qconf = &lcore_queue_conf[lcore_id];

            qconf->tx_port_list[qconf->n_tx_port] = portid;
            qconf->n_tx_port++;
            printf("Lcore %u: TX port %u\n", lcore_id, (unsigned) portid);
        }
    /* Now allocate RX lcores for each port. */
        lcore_id++;
        qconf = NULL;
        for (portid = 0; portid < nb_ports; portid++) {
            /* skip ports that are not enabled */
            if ((enabled_port_mask & (1 << portid)) == 0)
                continue;

            /* get the lcore_id for this port */
            while (rte_lcore_is_enabled(lcore_id) == 0 ||
                   lcore_queue_conf[lcore_id].n_rx_port ==
                   rx_queue_per_lcore) {
                lcore_id++;
                if (lcore_id >= RTE_MAX_LCORE)
                    rte_exit(EXIT_FAILURE, "Not enough cores\n");
            }

            if (qconf != &lcore_queue_conf[lcore_id])
                /* Assigned a new logical core in the loop above. */
                qconf = &lcore_queue_conf[lcore_id];

            qconf->rx_port_list[qconf->n_rx_port] = portid;
            qconf->n_rx_port++;
            printf("Lcore %u: RX port %u\n", lcore_id, (unsigned) portid);

        }
        break;
    default:
        /* Allocate RX lcores for each port. */
        rx_lcore_id = 0;
        qconf = NULL;
        for (portid = 0; portid < nb_ports; portid++) {
            /* skip ports that are not enabled */
            if ((enabled_port_mask & (1 << portid)) == 0)
                continue;

            /* get the lcore_id for this port */
            while (rte_lcore_is_enabled(rx_lcore_id) == 0 ||
                   lcore_queue_conf[rx_lcore_id].n_rx_port ==
                   rx_queue_per_lcore) {
                rx_lcore_id++;
                if (rx_lcore_id >= RTE_MAX_LCORE)
                    rte_exit(EXIT_FAILURE, "Not enough cores\n");
            }

            if (qconf != &lcore_queue_conf[rx_lcore_id])
                /* Assigned a new logical core in the loop above. */
                qconf = &lcore_queue_conf[rx_lcore_id];

            qconf->rx_port_list[qconf->n_rx_port] = portid;
            qconf->n_rx_port++;
            printf("Lcore %u: RX port %u\n", rx_lcore_id, (unsigned) portid);
        }
        break;
    }
    nb_ports_available = nb_ports;

    /* Initialise each port */
    for (portid = 0; portid < nb_ports; portid++) {
        /* skip ports that are not enabled */
        if ((enabled_port_mask & (1 << portid)) == 0) {
            printf("Skipping disabled port %u\n", (unsigned) portid);
            nb_ports_available--;
            continue;
        }
        /* init port */
        printf("Initializing port %u... ", (unsigned) portid);
        fflush(stdout);
        ret = rte_eth_dev_configure(portid, 1, 1, &port_conf);
        if (ret < 0)
            rte_exit(EXIT_FAILURE, "Cannot configure device: err=%d, port=%u\n",
                  ret, (unsigned) portid);

        rte_eth_macaddr_get(portid,&ports_eth_addr[portid]);

        /* set mtu */
        ret = rte_eth_dev_set_mtu(portid, MTU);
        if (ret < 0)
            RTE_LOG(INFO, TRAFGEN, "Cannot set MTU to %u: err=%d, port=%u\n",
                  MTU, ret, (unsigned) portid);

        /* init one RX queue */
        fflush(stdout);
        ret = rte_eth_rx_queue_setup(portid, 0, nb_rxd,
                         rte_eth_dev_socket_id(portid),
                         NULL,
                         pktmbuf_pool);
        if (ret < 0)
            rte_exit(EXIT_FAILURE, "rte_eth_rx_queue_setup:err=%d, port=%u\n",
                  ret, (unsigned) portid);

        /* init one TX queue on each port */
        fflush(stdout);
        ret = rte_eth_tx_queue_setup(portid, 0, nb_txd,
                rte_eth_dev_socket_id(portid),
#if DISABLE_OFFLOADS
                &tx_conf);
#else
                NULL);
#endif
        if (ret < 0)
            rte_exit(EXIT_FAILURE, "rte_eth_tx_queue_setup:err=%d, port=%u\n",
                ret, (unsigned) portid);

        /* Start device */
        ret = rte_eth_dev_start(portid);
        if (ret < 0)
            rte_exit(EXIT_FAILURE, "rte_eth_dev_start:err=%d, port=%u\n",
                  ret, (unsigned) portid);

        printf("done: \n");

        rte_eth_promiscuous_enable(portid);

        printf("Port %u, MAC address: %02X:%02X:%02X:%02X:%02X:%02X\n\n",
                (unsigned) portid,
                ports_eth_addr[portid].addr_bytes[0],
                ports_eth_addr[portid].addr_bytes[1],
                ports_eth_addr[portid].addr_bytes[2],
                ports_eth_addr[portid].addr_bytes[3],
                ports_eth_addr[portid].addr_bytes[4],
                ports_eth_addr[portid].addr_bytes[5]);

        /* initialize port stats */
        memset(&port_statistics, 0, sizeof(port_statistics));
    }

    if (!nb_ports_available) {
        rte_exit(EXIT_FAILURE,
            "All available ports are disabled. Please set portmask.\n");
    }

    check_all_ports_link_status(nb_ports, enabled_port_mask);

    lcore_id = rte_get_master_lcore();
    rte_timer_reset(&print_stats_timer,
                    timer_hz*timer_period,
                    PERIODICAL,
                    lcore_id,
                    print_stats_cb,
                    NULL);


    signal(SIGHUP, handle_signals);
    signal(SIGTERM, handle_signals);
    signal(SIGINT, handle_signals);
    signal(SIGUSR1, handle_signals);

    /* launch per-lcore init on every lcore */
    rte_eal_mp_remote_launch(launch_one_lcore, NULL, CALL_MASTER);
    RTE_LCORE_FOREACH_SLAVE(lcore_id) {
        if (rte_eal_wait_lcore(lcore_id) < 0) {
            fprintf(stderr,"Subprocess exited with error.\n");
            return -1;
        }
    }
    printf("Done!\n");
    update_stats();
    return 0;
}
