#!/bin/bash

irqbalance stop

#Load the kernel-mode UIO driver for the NFP VF's
modprobe nfp_uio

#Allocate and mount hugepages
echo 256 > /proc/sys/vm/nr_hugepages 2> /dev/null
mkdir -p /mnt/huge
grep -q hugetlbfs /proc/mounts || mount -t hugetlbfs nodev /mnt/huge
#Note: the following is dangerous to do when running multiple apps using
#hugepages!
rm -rf /mnt/huge/*

#This script assumes that the PCI device is currently attached to nfp_netvf
#and the netdev eth2.
ifconfig eth2 0 down
/opt/netronome/libexec/dpdk_nic_bind.py -b nfp_uio 00:09.0

./build/app/trafgen -c 0x3 -n 4 --proc-type auto --socket-mem 512 --file-prefix trafgen1 -d /opt/netronome/lib/librte_pmd_nfp_net.so -w 00:09.0 -- --benchmark --portmask 0x1 --runtime $1 --summary $2 --src-ip $3 --dst-ip $4 --src-mac $5 --dst-mac $6 --flows-per-stream $7 --packet-size $8 --pps $9 --tx-burst ${10}
